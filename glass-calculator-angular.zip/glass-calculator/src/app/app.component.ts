import { CommonModule } from '@angular/common';
import {
  Component,
  ElementRef,
  HostListener,
  OnInit,
  ViewChild,
} from '@angular/core';

interface HistoryEntry {
  expr: string;
  result: string;
}

type Theme = 'light' | 'dark';

const THEME_COLORS: Record<Theme, { a: string; b: string }> = {
  light: { a: '#EDE7DA', b: '#E1D9C4' },
  dark: { a: '#1b1826', b: '#0e0c14' },
};

const STORAGE_KEYS = {
  theme: 'calc-theme',
  history: 'calc-history',
  memory: 'calc-memory',
};

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './app.component.html',
})
export class AppComponent implements OnInit {
  currentValue = '0';
  previousValue = '';
  operator: string | null = null;
  resetNext = false;

  memory = 0;
  historyData: HistoryEntry[] = [];
  historyLine = '';

  sciOpen = false;
  memRowOpen = false;
  histOpen = false;
  theme: Theme = 'light';

  orb1Transform = '';
  orb2Transform = '';
  orb3Transform = '';
  private readonly orbFactors = [18, -14, 10];

  @ViewChild('currentDisplay') currentDisplayRef!: ElementRef<HTMLDivElement>;

  ngOnInit(): void {
    const savedTheme = localStorage.getItem(STORAGE_KEYS.theme);
    if (savedTheme === 'dark' || savedTheme === 'light') {
      this.theme = savedTheme;
      document.documentElement.setAttribute('data-theme', this.theme);
    }

    const savedHistory = localStorage.getItem(STORAGE_KEYS.history);
    if (savedHistory) {
      try {
        this.historyData = JSON.parse(savedHistory);
      } catch {
        this.historyData = [];
      }
    }

    const savedMemory = localStorage.getItem(STORAGE_KEYS.memory);
    if (savedMemory) this.memory = parseFloat(savedMemory) || 0;
  }

  // ---------- Derived display value ----------
  get displayValue(): string {
    return this.formatNumber(this.currentValue);
  }

  formatNumber(str: string): string {
    if (str === 'Error' || str === '' || str === undefined) return str;
    const neg = str.startsWith('-');
    if (neg) str = str.slice(1);
    let [intPart, decPart] = str.split('.');
    if (intPart === '') intPart = '0';
    const withCommas = intPart.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    let result = withCommas;
    if (decPart !== undefined) result += '.' + decPart;
    return (neg ? '-' : '') + result;
  }

  private pulse(): void {
    const el = this.currentDisplayRef?.nativeElement;
    if (!el) return;
    el.classList.remove('slide-in');
    void el.offsetWidth;
    el.classList.add('slide-in');
  }

  // ---------- Toggles ----------
  toggleSci(): void {
    this.sciOpen = !this.sciOpen;
  }

  toggleMemRow(): void {
    this.memRowOpen = !this.memRowOpen;
  }

  toggleHistory(): void {
    this.histOpen = !this.histOpen;
  }

  // ---------- Theme: circular flood transition ----------
  toggleTheme(e: MouseEvent): void {
    const target: Theme = this.theme === 'dark' ? 'light' : 'dark';
    const x = e.clientX;
    const y = e.clientY;
    this.runThemeTransition(x, y, target);
  }

  private runThemeTransition(x: number, y: number, target: Theme): void {
    const overlay = document.createElement('div');
    overlay.className = 'theme-transition-overlay';
    overlay.style.setProperty('--flood-a', THEME_COLORS[target].a);
    overlay.style.setProperty('--flood-b', THEME_COLORS[target].b);
    overlay.style.clipPath = `circle(0px at ${x}px ${y}px)`;
    document.body.appendChild(overlay);

    const maxRadius =
      Math.hypot(
        Math.max(x, window.innerWidth - x),
        Math.max(y, window.innerHeight - y)
      ) * 1.05;

    requestAnimationFrame(() => {
      overlay.style.transition = 'clip-path 0.65s cubic-bezier(.65,0,.35,1)';
      overlay.style.clipPath = `circle(${maxRadius}px at ${x}px ${y}px)`;
    });

    setTimeout(() => {
      this.theme = target;
      document.documentElement.setAttribute('data-theme', target);
      localStorage.setItem(STORAGE_KEYS.theme, target);
    }, 420);

    setTimeout(() => {
      overlay.style.transition = 'opacity 0.4s ease';
      overlay.style.opacity = '0';
    }, 650);

    setTimeout(() => overlay.remove(), 1080);
  }

  // ---------- Core calculator logic ----------
  appendNumber(num: string): void {
    if (this.resetNext) {
      this.currentValue = '0';
      this.resetNext = false;
    }
    if (num === '.' && this.currentValue.includes('.')) return;
    if (this.currentValue === '0' && num !== '.') this.currentValue = num;
    else this.currentValue += num;
    this.pulse();
  }

  appendOperator(op: string): void {
    if (this.operator !== null) this.calculate();
    this.previousValue = `${this.formatNumber(this.currentValue)} ${op}`;
    this.operator = op;
    this.resetNext = true;
  }

  private factorial(n: number): number {
    if (n < 0 || !Number.isInteger(n)) return NaN;
    if (n === 0) return 1;
    let r = 1;
    for (let i = 2; i <= n; i++) r *= i;
    return r;
  }

  applyFunc(fn: string): void {
    const val = parseFloat(this.currentValue);
    let result: number;
    let label = fn;
    switch (fn) {
      case 'sin': result = Math.sin((val * Math.PI) / 180); break;
      case 'cos': result = Math.cos((val * Math.PI) / 180); break;
      case 'tan': result = Math.tan((val * Math.PI) / 180); break;
      case 'sqrt': result = Math.sqrt(val); label = '√'; break;
      case 'log': result = Math.log10(val); break;
      case 'ln': result = Math.log(val); break;
      case 'fact': result = this.factorial(val); label = 'n!'; break;
      default: return;
    }
    const expr = `${label}(${val})`;
    this.historyLine = expr;
    this.currentValue = isNaN(result) ? 'Error' : String(parseFloat(result.toFixed(8)));
    this.resetNext = true;
    this.pushHistory(expr, this.currentValue);
    this.pulse();
  }

  calculate(): void {
    if (this.operator === null || this.resetNext) return;
    const prev = parseFloat(this.previousValue);
    const curr = parseFloat(this.currentValue);
    let result: number;

    switch (this.operator) {
      case '+': result = prev + curr; break;
      case '-': result = prev - curr; break;
      case '×': result = prev * curr; break;
      case '÷': result = curr === 0 ? NaN : prev / curr; break;
      case '%': result = prev % curr; break;
      case '^': result = Math.pow(prev, curr); break;
      default: return;
    }

    const expr = `${this.previousValue} ${this.formatNumber(this.currentValue)}`;
    this.historyLine = `${expr} =`;
    this.previousValue = '';
    this.currentValue = isNaN(result) ? 'Error' : String(parseFloat(result.toFixed(8)));
    this.operator = null;
    this.resetNext = true;
    this.pushHistory(expr, this.currentValue);
    this.pulse();
  }

  // ---------- History (persisted to localStorage) ----------
  private pushHistory(expr: string, result: string): void {
    if (result === 'Error') return;
    this.historyData.unshift({ expr, result });
    if (this.historyData.length > 30) this.historyData.pop();
    localStorage.setItem(STORAGE_KEYS.history, JSON.stringify(this.historyData));
  }

  reuseHistory(i: number): void {
    const h = this.historyData[i];
    this.currentValue = h.result;
    this.resetNext = true;
    this.histOpen = false;
    this.pulse();
  }

  clearHistory(e: Event): void {
    e.stopPropagation();
    this.historyData = [];
    localStorage.removeItem(STORAGE_KEYS.history);
  }

  // ---------- Memory (persisted to localStorage) ----------
  memClear(): void {
    this.memory = 0;
    localStorage.setItem(STORAGE_KEYS.memory, String(this.memory));
  }
  memRecall(): void {
    this.currentValue = String(this.memory);
    this.resetNext = true;
    this.pulse();
  }
  memAdd(): void {
    this.memory += parseFloat(this.currentValue) || 0;
    localStorage.setItem(STORAGE_KEYS.memory, String(this.memory));
  }
  memSub(): void {
    this.memory -= parseFloat(this.currentValue) || 0;
    localStorage.setItem(STORAGE_KEYS.memory, String(this.memory));
  }

  clearAll(): void {
    this.currentValue = '0';
    this.previousValue = '';
    this.operator = null;
    this.resetNext = false;
    this.historyLine = '';
    this.pulse();
  }

  deleteLast(): void {
    if (this.resetNext) return;
    this.currentValue = this.currentValue.length > 1 ? this.currentValue.slice(0, -1) : '0';
  }

  // ---------- Ripple ----------
  ripple(e: MouseEvent): void {
    const btn = e.currentTarget as HTMLElement;
    btn.classList.remove('ripple');
    void btn.offsetWidth;
    btn.classList.add('ripple');
  }

  // ---------- Parallax orbs ----------
  @HostListener('window:mousemove', ['$event'])
  onMouseMove(e: MouseEvent): void {
    const cx = window.innerWidth / 2;
    const cy = window.innerHeight / 2;
    const dx = (e.clientX - cx) / cx;
    const dy = (e.clientY - cy) / cy;
    this.orb1Transform = `translate(${dx * this.orbFactors[0]}px, ${dy * this.orbFactors[0]}px)`;
    this.orb2Transform = `translate(${dx * this.orbFactors[1]}px, ${dy * this.orbFactors[1]}px)`;
    this.orb3Transform = `translate(${dx * this.orbFactors[2]}px, ${dy * this.orbFactors[2]}px)`;
  }

  // ---------- Keyboard ----------
  @HostListener('window:keydown', ['$event'])
  onKeydown(e: KeyboardEvent): void {
    if (e.key >= '0' && e.key <= '9') this.appendNumber(e.key);
    else if (e.key === '.') this.appendNumber('.');
    else if (e.key === '+') this.appendOperator('+');
    else if (e.key === '-') this.appendOperator('-');
    else if (e.key === '*') this.appendOperator('×');
    else if (e.key === '/') { e.preventDefault(); this.appendOperator('÷'); }
    else if (e.key === '^') this.appendOperator('^');
    else if (e.key === 'Enter' || e.key === '=') this.calculate();
    else if (e.key === 'Backspace') this.deleteLast();
    else if (e.key === 'Escape') this.clearAll();
  }
}
