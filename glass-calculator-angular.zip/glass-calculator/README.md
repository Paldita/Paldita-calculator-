# Glass Calculator (Angular)

A glassmorphic calculator with scientific mode, memory, calculation history,
and a day/night theme switch with a circular "flood" transition. State
(theme, memory, history) is persisted in the browser via `localStorage`.

## Run locally

```bash
npm install
npm start
```

Then open http://localhost:4200.

## Build for production

```bash
npm install
npm run build
```

Output goes to `dist/calculator/browser`.

## Deploy to Vercel

**Option A — Vercel CLI**

```bash
npm install -g vercel
vercel
```

Vercel will read `vercel.json`, which already points at the correct build
command and output directory (`dist/calculator/browser`).

**Option B — Git + Vercel dashboard**

1. Push this folder to a GitHub/GitLab/Bitbucket repo.
2. Import the repo in the Vercel dashboard.
3. Vercel auto-detects the settings from `vercel.json` — no manual
   configuration needed. Click Deploy.

## Project structure

```
glass-calculator/
├── src/
│   ├── app/
│   │   ├── app.component.ts     Component logic
│   │   └── app.component.html   Template
│   ├── index.html               Shell + fonts
│   ├── main.ts                  Bootstrap
│   └── styles.css               Global glass/theme styles
├── angular.json
├── package.json
├── tsconfig*.json
└── vercel.json
```
